package ProjectSoftware.pkg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ProjectSoftware.pkg.*;

class CustomerTest {

	@Test
	void testPurchaseItems() {
		Frys_Food_and_Drug f = new Frys_Food_and_Drug(); // create the grocery store
        Company theCompany = new Company(); // the owners of the store
        Wholesaler theWholesaler = new Wholesaler(); // the wholesaler
        System_Store system = new System_Store(theCompany);
        
        Customer c1 = new Customer();   // test customer
        Worker w1 = new Worker();       // test worker
		w1.enterBuilding(f);
		c1.enterBuilding(f);
		c1.setMoney(10.0);
        Item vegetable = new Item("vegetable", 5.0, 1, true);
		w1.workCheckout();
		c1.getShoppingCart().add(vegetable);
		c1.purchaseItems(f);
		assert c1.getMoney() == 10.0 - vegetable.getPrice();
		

	}

	@Test
	void testReturnItems() {
		Frys_Food_and_Drug f = new Frys_Food_and_Drug(); // create the grocery store
        Company theCompany = new Company(); // the owners of the store
        Wholesaler theWholesaler = new Wholesaler(); // the wholesaler
        System_Store system = new System_Store(theCompany);
        
        Customer c1 = new Customer();   // test customer
        Worker w1 = new Worker();       // test worker
		w1.enterBuilding(f);
		c1.enterBuilding(f);
        Item vegetable = new Item("vegetable", 5.0, 1, true);
		w1.workCheckout();
		c1.getShoppingCart().add(vegetable);
		c1.returnItems(f);
		assert c1.getShoppingCart().isEmpty();
	}

	@Test
	void testGoCheckOut() {
		Frys_Food_and_Drug f = new Frys_Food_and_Drug(); // create the grocery store
        Company theCompany = new Company(); // the owners of the store
        Wholesaler theWholesaler = new Wholesaler(); // the wholesaler
        System_Store system = new System_Store(theCompany);
        
        Customer c1 = new Customer();   // test customer
		Worker w1 = new Worker();       // test worker
		w1.enterBuilding(f);

		c1.enterBuilding(f);
		c1.goCheckOut();
		assert c1.getLocation() == 3;
	}

}
