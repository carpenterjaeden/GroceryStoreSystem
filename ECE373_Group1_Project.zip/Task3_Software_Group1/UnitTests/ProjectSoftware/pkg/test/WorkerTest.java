package ProjectSoftware.pkg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ProjectSoftware.pkg.*;

class WorkerTest {

	@Test
	void testPurchaseItems() {
		Frys_Food_and_Drug f = new Frys_Food_and_Drug(); // create the grocery store
        Company theCompany = new Company(); // the owners of the store
		Item vegetable = new Item("vegetable", 5.0, 2, true);
		theCompany.addStock(vegetable);
        Wholesaler theWholesaler = new Wholesaler(); // the wholesaler
        System_Store system = new System_Store(theCompany);
        
        Customer c1 = new Customer();   // test customer
        Worker w1 = new Worker();       // test worker
		w1.enterBuilding(f);
		c1.enterBuilding(f);
		c1.setMoney(10.0);
		w1.workCheckout();
		c1.getShoppingCart().add(vegetable);
		c1.purchaseItems(f);
		assert theCompany.getMoney() == vegetable.getPrice() * 2;
	}

	@Test
	void testReturnItems() {
		Frys_Food_and_Drug f = new Frys_Food_and_Drug(); // create the grocery store
        Company theCompany = new Company(); // the owners of the store
        Wholesaler theWholesaler = new Wholesaler(); // the wholesaler
        System_Store system = new System_Store(theCompany);
        
        Customer c1 = new Customer();   // test customer
        Worker w1 = new Worker();       // test worker
		w1.enterBuilding(f);
		c1.enterBuilding(f);
        Item vegetable = new Item("vegetable", 5.0, 1, true);
		w1.workCheckout();
		c1.getShoppingCart().add(vegetable);
		c1.returnItems(f);
		assert c1.getShoppingCart().isEmpty();
	}

	@Test
	void testCheckCondition() {
		Frys_Food_and_Drug f = new Frys_Food_and_Drug(); // create the grocery store
        Company theCompany = new Company(); // the owners of the store
        Wholesaler theWholesaler = new Wholesaler(); // the wholesaler
        System_Store system = new System_Store(theCompany);
        
        Customer c1 = new Customer();   // test customer
        Worker w1 = new Worker();       // test worker

		w1.enterBuilding(f);
		Item vegetable = new Item("vegetable", 5.0, 1, false);
		assert w1.checkCondition(vegetable) == false;
	}

}
