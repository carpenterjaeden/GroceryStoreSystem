package ProjectSoftware.pkg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;

import ProjectSoftware.pkg.Company;
import ProjectSoftware.pkg.Item;
import ProjectSoftware.pkg.Wholesaler;

class CompanyTest {
	
	@Test
	void testPurchaseWholesaleList() {
		Wholesaler w1 = new Wholesaler();
		w1.setMoney(1500);
		Company c1 = new Company();
		Item vegetable = new Item("vegetable", 5.0, 20, true);
        Item bread = new Item("bread", 7.5, 24, true);
        Item golden_Hotdog = new Item("Golden HotDog", 99.99, 1, true);
        Item meat = new Item("meat", 4.25, 10, true);
        assert c1.getWholesaleList().isEmpty();
        c1.addToWholesaleList(vegetable);
        c1.addToWholesaleList(meat);
        c1.addToWholesaleList(bread);
        c1.addToWholesaleList(golden_Hotdog);
        ArrayList<Item> testList = new ArrayList<Item>();
        testList.add(vegetable);
        testList.add(meat);
        testList.add(bread);
        testList.add(golden_Hotdog);
        assertEquals(testList,c1.getWholesaleList());
        c1.purchaseWholesaleList(w1);
        assert c1.getWholesaleList().isEmpty();
		assertEquals(testList, c1.getStock());
		//fail("Not yet implemented");
	}

}
