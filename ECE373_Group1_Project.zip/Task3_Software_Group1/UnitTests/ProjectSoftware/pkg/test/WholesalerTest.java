package ProjectSoftware.pkg.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ProjectSoftware.pkg.*;

class WholesalerTest {

	@Test
	void testSellWholesale() {
		Item tomato = new Item("tomato", 10.00, 100, true);
		Wholesaler w1 = new Wholesaler();
		w1.addStock(tomato);
		w1.sellWholesale();
		assert w1.getStock().isEmpty();
		assert w1.getMoney() == tomato.getPrice() * tomato.getAmount() / 2;
	}

}
