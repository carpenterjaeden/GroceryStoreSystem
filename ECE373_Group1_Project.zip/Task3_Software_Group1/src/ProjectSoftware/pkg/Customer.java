package ProjectSoftware.pkg;
import java.util.ArrayList;


public class Customer extends Person {
	protected ArrayList<Item> shoppingList= new ArrayList<Item>();
	protected String paymentOption;
	protected ArrayList<Item> shoppingCart= new ArrayList<Item>();
	protected int aisle;

	/* aisle key:
		0 = no aisle
		1 = aisle 1
		etc.
		(5 aisle max)
	*/

	public Customer() {
		super();
		this.shoppingList = new ArrayList<Item>();
		this.paymentOption = "null";
		this.shoppingCart = new ArrayList<Item>();
		this.aisle = 0;

	}

	public ArrayList<Item> getShoppingList() {
		return this.shoppingList;
	}

	public String getPaymentOption() {
		return this.paymentOption;
	}

	public ArrayList<Item> getShoppingCart() {
		return this.shoppingCart;
	}

	public int getAisle() {
		return this.aisle;
	}

	public void setShoppingList(ArrayList<Item> shoppingList) {
		this.shoppingList = shoppingList;
	}

	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}

/*	SETTER REPLACED BY "addItem()"
	public void setShoppingCart(ArrayList<Item> shoppingCart) {
		this.shoppingCart = shoppingCart;
	} */

	public void setAisle(int aisle) {
		this.aisle = aisle;
	}

	public void addItem(int aisle, Item i, int num) {
		Item x = i;
		boolean hasItem = false;
		for (Item j : this.shoppingCart) {
			if (j.getName().equals(x.getName())) {
				hasItem = true;
				j.setAmount(j.getAmount()+1);
			}
		}
		if (!hasItem) {
			x.setAmount(num);
			this.shoppingCart.add(x);
		}
	}

	public void purchaseItems(Frys_Food_and_Drug f) {	// might change with worker availability complexity increase
		for (Worker w1 : f.workersInBuilding) {
			if (f.isWorkerAvailable()) {
				w1.purchaseItems(this);
				break;
				// make worker unavailable
			} else {
				System.out.println("Worker is unavailable.");
			}
		}
	}

	public void returnItems(Frys_Food_and_Drug f) {
		for (Worker w1 : f.workersInBuilding) {
			if (f.isWorkerAvailable()) {
				w1.returnItems(this);
				// make worker unavailable
			} else {
				System.out.println("Worker is unavailable.");
			}
		}
		for (int i = 0; i < shoppingCart.size(); i++) {
			shoppingCart.remove(i);
		}
	}

	public void enterAisle() {
		if (this.location == 1) {
			System.out.println("You enter aisle 1.");
			this.location = 2;
			this.aisle = 1;
		} else {
			System.out.println("You cannot enter the aisle from your location (Outside or at Checkout)");
			return;
		}
	}

	public void changeAisle(int a1) {
		if (this.location == 2) {
			System.out.println("You move to aisle " + a1 + ".");
			this.aisle = a1;
		} else {
			System.out.println("Unable to change aisles. \n(Must enterAisle before changing aisles)");
		}
	}

	public void exitAisle( ) {
		if (this.location == 2)	{
			System.out.println("You exit the aisle.");
			this.location = 1;
			this.aisle = 0;
		} else {
			System.out.println("You aren't in an aisle, cannot exit aisle.");
			return;
		}
	}


	public void goCheckOut() {
		if (this.location == 1) {
			System.out.println("You head to the checkout register.");
			this.location = 3;
		} else {
			System.out.println("You cannot reach the checkout register from this location.");
		}
	}
	
	public void printList() {
		for (Item i1 : this.shoppingList) {
			System.out.println(i1.getAmount() + " " + i1.getName() + "(s)");
		}
	}
	
	public void setListAsCart() {
		this.shoppingCart = this.shoppingList;
	}
}
