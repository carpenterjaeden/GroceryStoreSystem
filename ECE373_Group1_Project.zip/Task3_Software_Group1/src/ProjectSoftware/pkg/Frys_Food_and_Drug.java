package ProjectSoftware.pkg;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;

public class Frys_Food_and_Drug {
	public boolean open;
	public boolean onFire;
	public ArrayList<Customer> customerInBuilding = new ArrayList<Customer>();
	public ArrayList<Worker> workersInBuilding = new ArrayList<Worker>();
	public ArrayList<Wholesaler> wholesalers = new ArrayList<Wholesaler>();
	public ArrayList<Company> companies = new ArrayList<Company>();


	public Frys_Food_and_Drug() {
		this.open = false;
		this.onFire = false;
		this.customerInBuilding = new ArrayList<Customer>();
		this.workersInBuilding = new ArrayList<Worker>(); 
	}

	public void addWholesaler(Wholesaler ws) {
		wholesalers.add(ws);
	}

	public void addCompany(Company cm) {
		companies.add(cm);
	}

	public Wholesaler getWholesaler() {
		Random r = new Random();
		int randomInt = (int) r.nextInt(1);

		if (wholesalers.size() == 1) {
			return wholesalers.get(0);
		}

		if (randomInt == 0) {
			return wholesalers.get(0);
		}
		else {
			return wholesalers.get(1);
		}
	}

	public Company getCompany() {
		Random r = new Random();
		int randomInt = (int) r.nextInt(1);

		if (companies.size() == 1) {
			return companies.get(0);
		}

		if (randomInt == 0) {
			return companies.get(0);
		}
		else {
			return companies.get(1);
		}
	}



	public boolean getOpen() {
		return this.open;
	}

	public boolean getOnFire() {
		return this.onFire;
	}

	public ArrayList<Customer> getCustomersInBuilding() {
		return this.customerInBuilding;
	}

	public ArrayList<Worker> getWorkersInBuilding() {
		return this.workersInBuilding;
	}

	public void setOpen(boolean open) {
		this.open = open;
	}

	public void setOnFire(boolean onFire) {
		this.onFire = onFire;
	}

/* SETTER REPLACED BY "addPeople()"
	public void setPeopleInBuilding(ArrayList<Person> peopleInBuilding) {
	 	this.peopleInBuilding = peopleInBuilding; 
	} */

	public void addPeople( Worker w1 ) {
		this.workersInBuilding.add(w1);
		this.open = true;
	}

	public void addPeople( Customer c1) {
		this.customerInBuilding.add(c1);
	}
	
	public Customer getCustomer() {
		Random r = new Random();
		int randInt = r.nextInt(customerInBuilding.size());
		return customerInBuilding.get(randInt);
	}

	public void removePeople( Worker p1 ) {
		for (int i = 0; i < workersInBuilding.size(); i++) {
			if (workersInBuilding.get(i) == p1) {
				workersInBuilding.remove(i);
			}
		}
		if (workersInBuilding.size() < 1) {
			this.open = false;
		}
	}

	public void removePeople( Customer p1 ) {
		for (int i = 0; i < customerInBuilding.size(); i++) {
			if (customerInBuilding.get(i) == p1) {
				customerInBuilding.remove(i);
			}
		}
	}

	public boolean isWorkerAvailable() {		// change with complexity increase
		if (this.open == true) {
			return true;
		} else {
			return false;
		}
	}
}
