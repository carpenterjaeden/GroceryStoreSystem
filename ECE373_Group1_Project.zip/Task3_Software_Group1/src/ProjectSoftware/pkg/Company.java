package ProjectSoftware.pkg;
import java.util.ArrayList;


public class Company extends BusinessEntity {
	private ArrayList<Person> employeeList = new ArrayList<Person>();
	private ArrayList<Item> wholesaleList = new ArrayList<Item>();

	
	public ArrayList<Person> getEmployeeList() {
		return this.employeeList;
	}

	public void setEmployeeList(ArrayList<Person> employeeList) {
		this.employeeList = employeeList;
	}

	public void hireEmployee(Person p) {
		this.employeeList.add(p);
	}
	public void addToWholesaleList(Item i){
		this.wholesaleList.add(i);
	}
	
	public ArrayList<Item> getWholesaleList() {
		return wholesaleList;
	}

	public void setWholesaleList(ArrayList<Item> wholesaleList) {
		this.wholesaleList = wholesaleList;
	}

	public void purchaseWholesaleList(Wholesaler w) {
		for (Item i : this.wholesaleList) {
		w.sellWholesale();
		this.money = this.money - (i.getPrice()/2 * i.getAmount());
		this.stock.add(i);
		}
		ArrayList<Item> blank = new ArrayList<Item>();
		this.setWholesaleList(blank);
	}
	
	public void purchaseWholesale(Wholesaler w) {
		for (Item i : w.getStock()) {
			this.money = this.money - (i.getPrice()/2 * i.getAmount());
			this.stock.add(i);
		}
		w.sellWholesale();
	}
	
	public void printEmployee() {
		ArrayList <String> employee = new ArrayList<String>();
		System.out.println("Employee List:\n");
		for (Person w : employeeList) {
			if (!employee.contains(w.getName())) {
			System.out.println(w.getName());
			employee.add(w.getName());
			}
		}
	}
}
