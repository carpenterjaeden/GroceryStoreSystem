package ProjectSoftware.pkg;
import java.util.ArrayList;


public class Driver {
    public static void main(String[] args) {
        Frys_Food_and_Drug our_store = new Frys_Food_and_Drug(); // create the grocery store
        Company theCompany = new Company(); // the owners of the store
        Wholesaler theWholesaler = new Wholesaler(); // the wholesaler
        System_Store system = new System_Store(theCompany);
        
        Customer c1 = new Customer();   // test customer
        Worker w1 = new Worker();       // test worker

        /* Create Items */
        Item vegetable = new Item("vegetable", 5.0, 20, true);
        Item bread = new Item("bread", 7.5, 24, true);
        Item golden_Hotdog = new Item("Golden HotDog", 99.99, 1, true);
        Item meat = new Item("meat", 4.25, 10, true);

        /* Create Store_Stock */
        ArrayList<Item> stock = new ArrayList<Item>();
        stock.add(vegetable);
        stock.add(bread);
        stock.add(meat);
        stock.add(golden_Hotdog); 
        theCompany.setStock(stock);


        /* Person Attributes */
        c1.setName("Jaeden");
        c1.setMoney(100.0);
        // location and aisle are initialized in contstructor to 0.
        /* Customer Attributes */
        c1.setPaymentOption("Card");
            ArrayList<Item> list1 = new ArrayList<Item>();
            list1.add(vegetable);   // list1[0]
            list1.add(bread);       // list1[1]
            list1.add(meat);        // list1[2]
        c1.setShoppingList(list1);

        w1.setName("Employee");

        
    /* Customer Shopping + Employee Working */
        w1.enterBuilding(our_store);
        c1.enterBuilding(our_store);

        System.out.println("Jaeden's Shopping List: ");
        c1.PrintList(c1.shoppingList);

        w1.workCheckout();  // worker available for customer CheckOut
        c1.enterAisle();    // enter aisle 1 (vegetables)

        System.out.println("Testing if you can get the right items from the right aisles");
        c1.addItem(c1.getAisle(), c1.shoppingList.get(0), 2);
        c1.addItem(c1.getAisle(), c1.shoppingList.get(1), 1);
        c1.changeAisle(2);      // enter aisle 2 (vegetable and bread)
        c1.addItem(c1.getAisle(), c1.shoppingList.get(1), 1);
        c1.addItem(c1.getAisle(), c1.shoppingList.get(2), 1);
        c1.changeAisle(3);      // enter aisle 3 (bread)
        c1.addItem(c1.getAisle(), c1.shoppingList.get(2), 1);
        c1.changeAisle(4);      // enter aisle 4 (meat)
        c1.addItem(c1.getAisle(), c1.shoppingList.get(2), 1);

        c1.exitAisle();     // Customer moves to idle state
        System.out.println(c1.getName() + "'s Shopping Cart:");
        c1.PrintList(c1.shoppingCart);
        c1.goCheckOut();    // Customer moves to CheckOut

        System.out.println("Testing purchase items");
        c1.purchaseItems(our_store);
       
        c1.leaveBuilding(our_store);
    /* End Test */


    /* Wholesaler and Company Product Exchange Test */
        System.out.println("Wholesaler and Company Product Exchange Test");
        theWholesaler.setName("\"Factory\"");
        Item newProduct = new Item("LimitedItem", 14.50, 50, true);
        theWholesaler.addStock(newProduct);
        for (Item i : theWholesaler.getStock()) {
            theCompany.purchaseWholesale(theWholesaler);
            if (theWholesaler.getStock().size() == 0)
            	break;
        }
    /* End Test */

    
    /* Customer Returning Item Test */
        System.out.println("Customer Returning Item Test");
        Customer c2 = new Customer(); // test customer
            c2.setName("Sam");
        c2.shoppingCart.add(golden_Hotdog);

        c2.enterBuilding(our_store);
        System.out.println("Current Items:");
        c2.PrintList(c2.shoppingCart);

        System.out.println("Returning Items:");
        c2.returnItems(our_store);

        c2.leaveBuilding(our_store);

    /* End Test */
    }
}
