package ProjectSoftware.pkg;
import java.util.ArrayList;


public abstract class BusinessEntity {
	public ArrayList<Item> stock = new ArrayList<Item>();
	public static ArrayList<Wholesaler> wholesalerList = new ArrayList<Wholesaler>();
	protected String name;
	protected double money;

	public ArrayList<Item> getStock() {
		return stock;
	}

	public String getName() {
		return this.name;
	}

	public double getMoney() {
		return Math.round((this.money*100)/100);
	}

	public void setStock(ArrayList<Item> stock) {
		this.stock = stock;
	}

	public void addStock(Item stock) {
		this.stock.add(stock);
	}
	
	public void setName(String name) {
		this.name = name;
		Wholesaler w = new Wholesaler();
		if (this.getClass() == w.getClass()) {
			Wholesaler.wholesalerList.add((Wholesaler) this);
		}
	}

	public void setMoney(double money) {
		this.money = money;
	}
	
	public void printStock() { // name price amount
		for (Item it : this.stock) {
			System.out.println("Item Name: " + it.getName() + " Item Price: " + it.getPrice() + " Item Amount: " + it.getAmount());
		}
	}
}
