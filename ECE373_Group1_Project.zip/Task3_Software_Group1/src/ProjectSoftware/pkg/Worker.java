package ProjectSoftware.pkg;

import java.util.ArrayList;
import javax.swing.*;


public class Worker extends Person {
	private int trainingLevel;
	private boolean uniform;
	private int hoursLeft;
	private double salary;
	private Company employer;

	public Worker() {
		super();
		this.trainingLevel = 1;
		this.uniform = true;
		this.hoursLeft = 4;
		this.salary = 12.8;
		
	}
	
	public int getTrainingLevel() {
		return this.trainingLevel;
	}

	public boolean getUniform() {
		return this.uniform;
	}

	public int getHoursLeft() {
		return this.hoursLeft;
	}

	public double getSalary() {
		return this.salary;
	}

	public Company getEmployer() {
		return this.employer;
	}

	public void setTrainingLevel(int trainingLevel) {
		this.trainingLevel = trainingLevel;
	}

	public void setUniform(boolean uniform) {
		this.uniform = uniform;
	}

	public void setHoursLeft(int hoursLeft) {
		this.hoursLeft = hoursLeft;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public void hiredBy(Company c) {
		this.employer = c;
		c.hireEmployee(this);
	}

	public void workCheckout( ) {
		setSalary(12.8); // $12.80/hr is AZ min-wage
		this.location = 1;
		// TODO should be implemented
	}

	public void workReturns( ) {
		
	}

	public boolean checkCondition( Item item ) {
		if (item.getQuality() == true) {
			System.out.println("This item has good quality.");
			return true;
		} else {
			System.out.println("This item has poor quality.");
			return false;
		}
	}

// BELOW SHOULD CALL SYSTEM METHODS --> CONNECTS CUSTOMER TO COMPANY (item purchase removes item from company stock)

	public void purchaseItems(Customer c1) {
		double price = 0;
		boolean poor = false;
		for (Item i : c1.shoppingCart) {
			price = (i.getPrice()*i.getAmount()) + price;
			if (price > c1.getMoney()) {
				poor = true;
			}
		}
		if (!poor) {
			for (Item i : c1.shoppingCart) {
				
				String totPrice = String.format("%.2f", i.getAmount()*i.getPrice());
				c1.setMoney(c1.getMoney() - (i.getPrice() * i.getAmount()));
				JOptionPane.showMessageDialog(null, "<html>" + i.getAmount() + " " + i.getName() + " purchased.<br>"
						  + "Item Total: $" + totPrice + "</html>"
						  , "Transaction Complete", JOptionPane.PLAIN_MESSAGE);
				
				System_Store.makePurchase(i, c1);
				
				if (c1.getMoney() < 0) {
					JOptionPane.showMessageDialog(null, "The customer does not have enough money", "Transaction Declined", JOptionPane.PLAIN_MESSAGE);
					break;
				}
				
			}
		} else {
			JOptionPane.showMessageDialog(null, "The customer does not have enough money", "Transaction Declined", JOptionPane.PLAIN_MESSAGE);
		}
		int j = c1.shoppingCart.size();
		for (int i = 0; i < j; i++) {
			c1.shoppingCart.remove(0);
		}
	}

	public void returnItems(Customer c1) {
		for (Item i : c1.shoppingCart) {
			System_Store.makeReturn(i, c1);
			System.out.println(i.getName() + " was returned.");
		}
	}
}
