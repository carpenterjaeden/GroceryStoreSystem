package ProjectSoftware.pkg;
import java.util.ArrayList;

public class Item {
	private String name;
	private double price;
	private int amount;
	private boolean quality;

	public Item() {
		this.name = "null";
		this.price = 0.0;
		this.amount = 1;
		this.quality = true;
	}

	public Item(String n, double p, int a, boolean q) {
		this.name = n;
		this.price = p;
		this.amount = a;
		this.quality = q;
	}

	public String getName() {
		return this.name;
	}

	public double getPrice() {
		return this.price;
	}

	public int getAmount() {
		return this.amount;
	}

	public boolean getQuality() {
		return this.quality;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public void setQuality(boolean quality) {
		this.quality = quality;
	}

}
