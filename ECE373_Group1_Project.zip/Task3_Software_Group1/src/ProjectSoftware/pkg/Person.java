package ProjectSoftware.pkg;
import java.util.ArrayList;

public abstract class Person {
	protected String name;
	protected double money;
	protected int location;
	public static ArrayList<Person> persons = new ArrayList<Person>();
	/* location key:
		0 = outside
		1 = inside (idle location)
		2 = aisle
		3 = register
	*/
	public Person() {
		this.name = "null";
		this.money = 0.0;
		this.location = 0;
		persons.add(this);
	}


	public String getName() {
		return this.name;
	}

	public double getMoney() {
		return this.money;
	}

	public int getLocation() {
		return this.location;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setMoney(double money) {
		this.money = money;
	}

	public void setLocation(int location) {
		this.location = location;
	}

	public void enterBuilding(Frys_Food_and_Drug f) {
		if (this instanceof Customer) {
			if (this.location == 0 && f.getOnFire() == false) {
				if (f.workersInBuilding.size() > 0) {
					System.out.println("You've entered Fry's Food and Drug Store.");
					this.location = 1;
					f.addPeople((Customer)this);
				} else if (f.workersInBuilding.size() < 1) {
					System.out.println("The Fry's is Locked. Wait for an employee to unlock the building.");
				}
			}
		} else if (this instanceof Worker) {
			if (f.workersInBuilding.size() > 0) {
				System.out.println("You've entered Fry's Food and Drug Store.");
				this.location = 1;
				f.addPeople((Worker)this);
			} else if (f.workersInBuilding.size() < 1) {
				System.out.println("You Unlock the Fry's Food and Drug Store.");
				this.location = 1;
				f.addPeople((Worker)this);
				f.setOpen(true);
			}
		} else {
			if (f.getOnFire() == false) {
				System.out.println("You are already inside the Fry's Food and Drug Store.");
			} else {
				System.out.println("The building is on fire.");
			}
		}
	}

	public void leaveBuilding(Frys_Food_and_Drug f) {
		System.out.println("You exit the Fry's Food and Drug Store.");
		this.location = 0;
		if (this instanceof Customer) {
			for (Customer p : f.getCustomersInBuilding()) {
				if (this == p) {
					f.customerInBuilding.remove(this);
					return;
				}
			}
		} else if (this instanceof Worker) {
			for (Person p : f.getWorkersInBuilding()) {
				if (this == p) {
					f.workersInBuilding.remove(this);
					return;
				}
			}
		} else {
			System.out.println("You cannot leave.");
		}
	}

	public void PrintList(ArrayList<Item> list) {
		int count = 1;
		System.out.println("Shopping List:");
		for(Item i : list) {
			System.out.println(count + ": " + i.getAmount() + " " + i.getName() + "(s)");
			count++;
		}
	}
}
