package ProjectSoftware.pkg;
import java.util.ArrayList;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

public class Frys_GUI extends JFrame{
    
    private Frys_Food_and_Drug fry;
    private JMenuBar menuBar;
    private GridLayout grid = new GridLayout();
    private ArrayList<Customer> checkedOut = new ArrayList<Customer>();
    
    private Customer checkOutCustomer;

    private JMenu window;
    private JMenuItem exit;

    private JMenu help;
    private JMenuItem loc;
    private JMenuItem list;
    private JMenuItem wallet;
    
    private JMenu actions;
    private JMenuItem drive;
    private JMenuItem sell;
    private JMenuItem printCompany;
    private JMenuItem workerPay;
    private JMenuItem employeeListCompany;

	public boolean listDone = false;

/*  Declares private variables within the GUI class so that all methods have access to these variable without re-initialization.
 * 	These are pseudo-global variables due to repeated use of the JMenuItems and JMenu's across multiple GUI's.
 */	
	
	
// The character variables that will inherit the selected playable characters methods and objects
    private Person playable;
    private BusinessEntity playable_2;
   
// Default Constructor that builds the character select screen to start the game.
    public Frys_GUI(String windowTitle, Frys_Food_and_Drug fry) {
        super(windowTitle);
        this.fry = fry;
        setSize(800,700); // scales the frame to (width, height)
        setLocationRelativeTo(null); // centers the frame on the screen
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        JLabel title;
        // Builds the initial frame and window with proper scaling, layout, and program termination if closed.
        
        	title = new JLabel("<html><center>Choose your character. <br>Click on the character.</center></html>");
            c.fill = GridBagConstraints.CENTER;
            c.ipady = 60;      // height of component
            c.weightx = 0.7;   // Spacing priority against overlapping components
            c.gridwidth = 2;   // GridBag Layout cells used in row
            c.gridx = 1;	   
            c.gridy = 0;	
            // GridBad Layout cell placement
            add(title, c);
        // Adds an instruction text box 
            
            ImageIcon image1 = new ImageIcon(getClass().getResource("/Customer_Icon.png"));
        	Image img = image1.getImage();
        	Image imgscaled = img.getScaledInstance(350, 150, java.awt.Image.SCALE_SMOOTH);
        	ImageIcon icon = new ImageIcon(imgscaled);
        	// Calls the Customer_Icon image from resources and scales it
        	JButton customer = new JButton(icon);
            customer.setContentAreaFilled(false);
            customer.setActionCommand("customer");
            // Creates the customer selection button with the image as the button
            c.fill = GridBagConstraints.HORIZONTAL;
            c.weightx = 0.5;
            c.gridwidth = 1;
            c.gridx = 1;
            c.gridy = 2;
            // GridBag Layout scaling and placement
            add(customer, c);
            customer.addActionListener(new ButtonListener());
            customer.addActionListener(e -> this.dispose()); // closes the previous GUI upon button click
            // adds the button to the frame and gives it function
         
            image1 = new ImageIcon(getClass().getResource("/Worker_Icon.png"));
            img = image1.getImage();
        	imgscaled = img.getScaledInstance(350, 150, java.awt.Image.SCALE_SMOOTH);
        	icon = new ImageIcon(imgscaled);
            // Calls the Worker_Icon image from resources and scales it
            JButton worker = new JButton(icon);
            worker.setContentAreaFilled(false);
            worker.setActionCommand("worker");
            // Creates the worker selection button with the image as the button
            c.fill = GridBagConstraints.HORIZONTAL;
            c.weightx = 0.5;
            c.gridwidth = 1;
            c.gridx = 2;
            c.gridy = 2;
            // GridBag Layout scaling and placement
            add(worker, c);
            worker.addActionListener(new ButtonListener());
            worker.addActionListener(e -> this.dispose()); // see line 84
            // adds the button to the frame and lets it function
         
            image1 = new ImageIcon(getClass().getResource("/Company_Icon.png"));
            img = image1.getImage();
        	imgscaled = img.getScaledInstance(350, 150, java.awt.Image.SCALE_SMOOTH);
        	icon = new ImageIcon(imgscaled);
            // Calls the Company_Icon image from resources and scales it
            JButton company = new JButton(icon);
            company.setContentAreaFilled(false);
            company.setActionCommand("company");
            // Creates the company selection button with the image as the button
            c.fill = GridBagConstraints.HORIZONTAL;
            c.weightx = 0.5;
            c.gridwidth = 1;
            c.gridx = 1;
            c.gridy = 3;
            // GridBag Layout scaling and placement
            add(company, c);
			company.addActionListener(new ButtonListener());
            company.addActionListener(e -> this.dispose());
            // adds the button to the frame and lets it function
            
            image1 = new ImageIcon(getClass().getResource("/Wholesaler_Icon.png"));
            img = image1.getImage();
        	imgscaled = img.getScaledInstance(350, 150, java.awt.Image.SCALE_SMOOTH);
        	icon = new ImageIcon(imgscaled);
            // Calls the Wholesaler_Icon image from resources and scales it
            JButton wholesaler = new JButton(icon);
            wholesaler.setContentAreaFilled(false);
            wholesaler.setActionCommand("wholesaler");
            // Creates the wholesaler selection button with the image as the button
            c.fill = GridBagConstraints.HORIZONTAL;
            c.weightx = 0.5;
            c.gridwidth = 1;
            c.gridx = 2;
            c.gridy = 3;
            // GridBag Layout scaling and placement
            add(wholesaler, c);
            wholesaler.addActionListener(new ButtonListener());
            wholesaler.addActionListener(e -> this.dispose());
            // adds the button to the frame and lets it function
        
        getContentPane().setBackground(Color.LIGHT_GRAY); // colors the background
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // terminates the program if the window is closed with no button press
		baseGUI(); // builds the JMenu (see line 844)
		setVisible(true); // opens the frame to be seen

    }
    
// OUTSIDE AS CUSTOMER
    private void customerGUI() {
    	JFrame frame = new JFrame("Customer");
        frame.setSize(1250,750);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        // Builds the frame after customer player is selected
    // Menu Bar
    	menuBar = new JMenuBar();
    	help = new JMenu("Help");
        loc = new JMenuItem("Current Location");
        list = new JMenuItem("Print Shopping List");
        exit = new JMenuItem("Exit");
        String money = String.format("%.2f", playable.getMoney());
        wallet = new JMenuItem("Wallet: $" + money);
        // creates the JMenuBar and the items on it
        help.add(loc);
        help.add(list);
        help.add(wallet);
        help.add(exit);
        // adds the items to the bar
        loc.addActionListener(new MenuListener());
        list.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        // gives the buttons functions if pressed
        menuBar.add(help);
        frame.setJMenuBar(menuBar);
        // adds the MenuBar to the frame
    // Background
        ImageIcon background = new ImageIcon(getClass().getResource("/Fry.jpeg"));
        // sets the background image to the Fry.jpeg image
        if (fry.getOnFire() == true) {
        	background = new ImageIcon(getClass().getResource("/Fire.png"));
        	// if the randomizer in the driver sets OnFire to true, this background will show instead
        }
        JLabel label = new JLabel(background);
    	frame.add(label);
    	// adds the background to the frame
    // Enter Building
    	JButton start = new JButton("Enter Fry's");
        start.setBounds(560, 495, 100, 50);
        label.add(start);
        // Adds the button to let the customer enter the building
        if (fry.getOnFire() == true) {
        	// if the building is on fire, the button will receive the action command "fire"
        	start.setActionCommand("fire");
        } else {
        	// if the building is not on fire, the button will receive the action command "enter"
        	start.setActionCommand("enter");
        }
        start.addActionListener(new ButtonListener());
        start.addActionListener(e -> frame.dispose());
        // adds function to the button and closes the previous GUI window
    // Build GUI
        frame.setVisible(true);
        // displays the GUI frame
    }
// INSIDE AS CUSTOMER
    private void buildingGUI() {
    	// Idle state of the player (see state diagrams)
    	JFrame frame = new JFrame("Fry's");
    	frame.setSize(1250,750);
    	frame.setLocationRelativeTo(null);
    	frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	// builds the frame and scales it
    // Menu Bar
    	menuBar = new JMenuBar();
    	help = new JMenu("Help");
        loc = new JMenuItem("Current Location");
        list = new JMenuItem("Print Shopping List");
        String money = String.format("%.2f", playable.getMoney());
        wallet = new JMenuItem("Wallet: $" + money);
        exit = new JMenuItem("Exit");
        help.add(loc);
        help.add(list);
        help.add(wallet);
        help.add(exit);
        loc.addActionListener(new MenuListener());
        list.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        menuBar.add(help);
        frame.setJMenuBar(menuBar);
        // adds the MenuBar to the frame (see line 161)
        JMenu cart = new JMenu("Shopping Cart");
		for (Item i : ((Customer)playable).getShoppingCart()) {
			String price = String.format("%.2f", i.getPrice() * i.getAmount());
			JMenuItem x = new JMenuItem(i.getAmount() + ": " + i.getName() + " : $" + price);
			cart.add(x);
		}
		menuBar.add(cart);
		// adds another item to the menu bar to display the customer's shopping cart (should initially be empty)
    // Background
    	ImageIcon background = new ImageIcon(getClass().getResource("/Inside_Image.png"));
    	Image img = background.getImage();
    	Image imgscaled = img.getScaledInstance(1250, 750, java.awt.Image.SCALE_SMOOTH);
    	ImageIcon pic = new ImageIcon(imgscaled);
    	JLabel label = new JLabel(pic);
    	frame.add(label);
    	// adds the background image to the frame and scales it
    // Navigation
    	// enter aisle 1 (access other aisles from aisle 1)
    	JButton aisle = new JButton("Enter Aisle1");
    	aisle.setBounds(560, 550, 100, 50);
    	label.add(aisle);
    	aisle.setActionCommand("aisle1");
    	aisle.addActionListener(new ButtonListener());
    	aisle.addActionListener(e -> frame.dispose());
    	// creates a button that allows for navigation into the fry's aisles
    	// go to checkout
    	JButton checkOut = new JButton("To Register");
    	checkOut.setBounds(210, 550, 100, 50);
    	label.add(checkOut);
    	checkOut.setActionCommand("register");
    	checkOut.addActionListener(new ButtonListener());
    	checkOut.addActionListener(e -> frame.dispose());
    	// sends the player to the register checkout screen
    // Build GUI
    	frame.setVisible(true);
    }
// AISLE AS CUSTOMER    
    public void aisleGUI() {
        // Menu Bar
		menuBar = new JMenuBar();
		help = new JMenu("Help");
		loc = new JMenuItem("Current Location");
		list = new JMenuItem("Print Shopping List");
		String money = String.format("%.2f", playable.getMoney());
        wallet = new JMenuItem("Wallet: $" + money);
		exit = new JMenuItem("Exit");
		help.add(loc);
		help.add(list);
		help.add(wallet);
		help.add(exit);
		loc.addActionListener(new MenuListener());
		list.addActionListener(new MenuListener());
		exit.addActionListener(new MenuListener());
		JMenu cart = new JMenu("Shopping Cart");
		for (Item i : ((Customer)playable).getShoppingCart()) {
			String price = String.format("%.2f", i.getPrice() * i.getAmount());
			JMenuItem x = new JMenuItem(i.getAmount() + ": " + i.getName() + " : $" + price);
			cart.add(x);
		}	
		menuBar.add(help);
		menuBar.add(cart);
		// builds the JMenu
		// Background Image 
		ImageIcon background = new ImageIcon(getClass().getResource("/Aisle_1.png"));
		Image img = background.getImage();
		Image imgscaled = img.getScaledInstance(1250, 750, java.awt.Image.SCALE_SMOOTH);
		ImageIcon pic = new ImageIcon(imgscaled);
		JLabel label = new JLabel(pic);
		// randomizer
		Random rand = new Random();
		int upper = 4;
		JButton i1 = new JButton();
		JButton i2 = new JButton();
		int rand_int = rand.nextInt(upper);
		// Creates a randomized integer from 0 to "upper" (non inclusive of the upper bound) --> (highest possible value is upper-1)
// Aisle generator
    	switch(((Customer)playable).getAisle()) {
    	// Switch case for which aisle the character is in (5 possible options : 1, 2, 3, 4, 5) --> Aisle 0 is "not in an aisle"
    	case 1: // AISLE 1
    		JFrame frame = new JFrame("Aisle 1: Vegetables");
    		frame.setSize(1250,750);
    		frame.setLocationRelativeTo(null);
    		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    // MenuBar
    		frame.setJMenuBar(menuBar);
    // Add Background
    		frame.add(label);
    		frame.setVisible(true);
    // Shelved Item spawns
    		switch(rand_int) {
    		// uses the randomized integer to generate 1 of 4 possible aisle layouts
    		// each aisle layout will have different placement or combination of items available
    		case 0:
    			ImageIcon corn_1 = new ImageIcon(getClass().getResource("/corn_1.png"));
    			Image corn = corn_1.getImage();
    			Image cornShape = corn.getScaledInstance(85, 52, java.awt.Image.SCALE_SMOOTH);
    			ImageIcon corn2 = new ImageIcon(cornShape);
    			i1 = new JButton(corn2);
    			i1.setBounds(115, 505, 85, 52);
    			label.add(i1);
    			// creates and places the corn item button
    			i1.setActionCommand("itemV");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			// adds function to the corn item button
    			break;
    		case 1:
    			ImageIcon potato_1 = new ImageIcon(getClass().getResource("/potato_1.png"));
    			Image potato = potato_1.getImage();
    			Image potatoShape = potato.getScaledInstance(65, 60, java.awt.Image.SCALE_SMOOTH);
    			ImageIcon potato2 = new ImageIcon(potatoShape);
    			i1 = new JButton(potato2);
    			i1.setBounds(1030, 285, 65, 60);
    			label.add(i1);
    			// creates and places the potato item button
    			i1.setActionCommand("itemV");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			// adds function to the potato item button
    			break;
    		case 2:
    			ImageIcon tomato_1 = new ImageIcon(getClass().getResource("/tomato_1.png"));
    			Image tomato = tomato_1.getImage();
    			Image tomatoShape = tomato.getScaledInstance(55, 50, java.awt.Image.SCALE_SMOOTH);
    			ImageIcon tomato2 = new ImageIcon(tomatoShape);
    			i1 = new JButton(tomato2);
    			i1.setBounds(813, 373, 55, 50);
    			label.add(i1);
    			i1.setActionCommand("itemV");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			// tomato button
    			break;
    		case 3:
    			ImageIcon kale_1 = new ImageIcon(getClass().getResource("/kale_1.png"));
    			Image kale = kale_1.getImage();
    			Image kaleShape = kale.getScaledInstance(100, 55, java.awt.Image.SCALE_SMOOTH);
    			ImageIcon kale2 = new ImageIcon(kaleShape);
    			i1 = new JButton(kale2);
    			i1.setBounds(270, 448, 100, 55);
    			label.add(i1);
    			i1.setActionCommand("itemV");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			// kale button
    			break;
    		default:
    			break;
    		}		
    	
    		JButton change = new JButton("Change Aisle");
    		change.setBounds(640, 630, 100, 50);
    		label.add(change);
    		change.setActionCommand("aisleNext");
    		change.addActionListener(new ButtonListener());
    		change.addActionListener(e -> frame.dispose());
    		// places a button that allows the player to change which aisle they're in 
    		JButton leave = new JButton("Exit Aisle");
    		leave.setBounds(500, 630, 100, 50);
    		label.add(leave);
    		leave.setActionCommand("aisle0");
    		leave.addActionListener(new ButtonListener());
    		leave.addActionListener(e -> frame.dispose());
    		// places a button that allows the player to exit their aisle (return to idle state/screen)
    		break;
    	case 2: // AISLE 2
    		frame = new JFrame("Aisle 2: Vegetables and Bread");
    		frame.setSize(1250,750);
    		frame.setLocationRelativeTo(null);
    		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    // MenuBar
    		frame.setJMenuBar(menuBar);
    // Background
    		frame.add(label);
    		frame.setVisible(true);
    // Shelved Item spawns
    		switch(rand_int) {
    		// SEE AISLE 1 (line 315 for aisle code breakdown)
    		case 0:
    			ImageIcon bread_2 = new ImageIcon(getClass().getResource("/bread_2.png"));
    			Image bread = bread_2.getImage();
    			Image breadShape = bread.getScaledInstance(160, 180, java.awt.Image.SCALE_SMOOTH);
    			ImageIcon bread2 = new ImageIcon(breadShape);
    			i1 = new JButton(bread2);
    			i1.setBounds(1030, 500, 160, 180);
    			label.add(i1);
    			i1.setActionCommand("itemB");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			ImageIcon pepper_1 = new ImageIcon(getClass().getResource("/pepper_1.png"));
    			Image pepper = pepper_1.getImage();
    			Image pepperShape = pepper.getScaledInstance(85, 52, java.awt.Image.SCALE_SMOOTH);
    			ImageIcon pepper2 = new ImageIcon(pepperShape);
    			i2 = new JButton(pepper2);
    			i2.setBounds(115, 505, 85, 52);
    			label.add(i2);
    			i2.setActionCommand("itemV");
    			i2.addActionListener(new ButtonListener());
    			i2.addActionListener(e -> frame.dispose());
    			break;
    		case 1:
    			ImageIcon bread_1 = new ImageIcon(getClass().getResource("/bread_1.jpeg"));
    			bread = bread_1.getImage();
    			breadShape = bread.getScaledInstance(350, 50, java.awt.Image.SCALE_SMOOTH);
    			bread2 = new ImageIcon(breadShape);
    			i1 = new JButton(bread2);
    			i1.setBounds(115, 505, 350, 52);
    			label.add(i1);
    			i1.setActionCommand("itemB");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			ImageIcon onion_1 = new ImageIcon(getClass().getResource("/onion_1.png"));
    			Image onion = onion_1.getImage();
    			Image onionShape = onion.getScaledInstance(70, 60, java.awt.Image.SCALE_SMOOTH);
    			ImageIcon onion2 = new ImageIcon(onionShape);
    			i2 = new JButton(onion2);
    			i2.setBounds(1030, 287, 70, 60);
    			label.add(i2);
    			i2.setActionCommand("itemV");
    			i2.addActionListener(new ButtonListener());
    			i2.addActionListener(e -> frame.dispose());
    			break;
    		case 2:
    			bread_2 = new ImageIcon(getClass().getResource("/bread_2.png"));
    			bread = bread_2.getImage();
    			breadShape = bread.getScaledInstance(160, 180, java.awt.Image.SCALE_SMOOTH);
    			bread2 = new ImageIcon(breadShape);
    			i1 = new JButton(bread2);
    			i1.setBounds(1030, 500, 160, 180);
    			label.add(i1);
    			i1.setActionCommand("itemB");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			bread_1 = new ImageIcon(getClass().getResource("/bread_1.jpeg"));
    			bread = bread_1.getImage();
    			breadShape = bread.getScaledInstance(350, 50, java.awt.Image.SCALE_SMOOTH);
    			bread2 = new ImageIcon(breadShape);
    			i2 = new JButton(bread2);
    			i2.setBounds(115, 505, 350, 52);
    			label.add(i2);
    			i2.setActionCommand("itemB");
    			i2.addActionListener(new ButtonListener());
    			i2.addActionListener(e -> frame.dispose());
    			break;
    		case 3:
    			onion_1 = new ImageIcon(getClass().getResource("/onion_1.png"));
    			onion = onion_1.getImage();
    			onionShape = onion.getScaledInstance(70, 60, java.awt.Image.SCALE_SMOOTH);
    			onion2 = new ImageIcon(onionShape);
    			i1 = new JButton(onion2);
    			i1.setBounds(1030, 287, 70, 60);
    			label.add(i1);
    			i1.setActionCommand("itemV");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			pepper_1 = new ImageIcon(getClass().getResource("/pepper_1.png"));
    			pepper = pepper_1.getImage();
    			pepperShape = pepper.getScaledInstance(85, 52, java.awt.Image.SCALE_SMOOTH);
    			pepper2 = new ImageIcon(pepperShape);
    			i2 = new JButton(pepper2);
    			i2.setBounds(115, 505, 85, 52);
    			label.add(i2);
    			i2.setActionCommand("itemV");
    			i2.addActionListener(new ButtonListener());
    			i2.addActionListener(e -> frame.dispose());
    			break;
    		default:
    			break;
    		}		
    		change = new JButton("Change Aisle");
    		change.setBounds(640, 630, 100, 50);
    		label.add(change);
    		change.setActionCommand("aisleNext");
    		change.addActionListener(new ButtonListener());
    		change.addActionListener(e -> frame.dispose());
    		leave = new JButton("Exit Aisle");
    		leave.setBounds(500, 630, 100, 50);
    		label.add(leave);
    		leave.setActionCommand("aisle0");
    		leave.addActionListener(new ButtonListener());
    		leave.addActionListener(e -> frame.dispose());
    		break;
    	
    	case 3: // AISLE 3
    		frame = new JFrame("Aisle 3: Bread");
    		frame.setSize(1250,750);
    		frame.setLocationRelativeTo(null);
    		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    		// SEE AISLE 1 (line 315 for breakdown)
    // MenuBar
    		frame.setJMenuBar(menuBar);
    // Background
    		frame.add(label);
    		frame.setVisible(true);
    // Shelved Item spawns
    		switch(rand_int) {
    		case 0:
    			ImageIcon bread_1 = new ImageIcon(getClass().getResource("/bread_2.png"));
    			Image bread = bread_1.getImage();
    			Image breadShape = bread.getScaledInstance(160, 180, java.awt.Image.SCALE_SMOOTH);
    			ImageIcon bread2 = new ImageIcon(breadShape);
    			i1 = new JButton(bread2);
    			i1.setBounds(1030, 500, 160, 180);
    			label.add(i1);
    			i1.setActionCommand("itemB");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			break;
    		case 1:
    			bread_1 = new ImageIcon(getClass().getResource("/bread_1.jpeg"));
    			bread = bread_1.getImage();
    			breadShape = bread.getScaledInstance(350, 50, java.awt.Image.SCALE_SMOOTH);
    			bread2 = new ImageIcon(breadShape);
    			i2 = new JButton(bread2);
    			i2.setBounds(115, 505, 350, 52);
    			label.add(i2);
    			i2.setActionCommand("itemB");
    			i2.addActionListener(new ButtonListener());
    			i2.addActionListener(e -> frame.dispose());
    			break;
    		case 2:
    			bread_1 = new ImageIcon(getClass().getResource("/bread_3.png"));
    			bread = bread_1.getImage();
    			breadShape = bread.getScaledInstance(120, 75, java.awt.Image.SCALE_SMOOTH);
    			bread2 = new ImageIcon(breadShape);
    			i2 = new JButton(bread2);
    			i2.setBounds(462, 430, 120, 75);
    			label.add(i2);
    			i2.setActionCommand("itemB");
    			i2.addActionListener(new ButtonListener());
    			i2.addActionListener(e -> frame.dispose());
    			break;
    		case 3:
    			bread_1 = new ImageIcon(getClass().getResource("/bread_4.png"));
    			bread = bread_1.getImage();
    			breadShape = bread.getScaledInstance(160, 65, java.awt.Image.SCALE_SMOOTH);
    			bread2 = new ImageIcon(breadShape);
    			i2 = new JButton(bread2);
    			i2.setBounds(95, 285, 160, 65);
    			label.add(i2);
    			i2.setActionCommand("itemB");
    			i2.addActionListener(new ButtonListener());
    			i2.addActionListener(e -> frame.dispose());
    			break;
    		default:
    			break;
    		}		
    		change = new JButton("Change Aisle");
    		change.setBounds(640, 630, 100, 50);
    		label.add(change);
    		change.setActionCommand("aisleNext");
    		change.addActionListener(new ButtonListener());
    		change.addActionListener(e -> frame.dispose());
    		leave = new JButton("Exit Aisle");
    		leave.setBounds(500, 630, 100, 50);
    		label.add(leave);
    		leave.setActionCommand("aisle0");
    		leave.addActionListener(new ButtonListener());
    		leave.addActionListener(e -> frame.dispose());
    		break;
    	case 4: // AISLE 4
    		frame = new JFrame("Aisle 4: Meat");
    		frame.setSize(1250,750);
    		frame.setLocationRelativeTo(null);
    		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    		// SEE AISLE 1 (line 315) FOR COMMENTS
    // MenuBar
    		frame.setJMenuBar(menuBar);
    // Background
    		frame.add(label);
    		frame.setVisible(true);
    // Shelved Item spawns
    		switch(rand_int) {
    		case 0:
    			ImageIcon meat_1 = new ImageIcon(getClass().getResource("/meat_1.png"));
    			Image meat = meat_1.getImage();
    			Image meatShape = meat.getScaledInstance(112, 52, java.awt.Image.SCALE_SMOOTH);
    			ImageIcon meat2 = new ImageIcon(meatShape);
    			i1 = new JButton(meat2);
    			i1.setBounds(813, 373, 112, 52);
    			label.add(i1);
    			i1.setActionCommand("itemM");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			break;
    		case 1:
    			meat_1 = new ImageIcon(getClass().getResource("/meat_2.png"));
    			meat = meat_1.getImage();
    			meatShape = meat.getScaledInstance(87, 47, java.awt.Image.SCALE_SMOOTH);
    			meat2 = new ImageIcon(meatShape);
    			i1 = new JButton(meat2);
    			i1.setBounds(118, 508, 87, 47);
    			label.add(i1);
    			i1.setActionCommand("itemM");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			break;
    		case 2:
    			meat_1 = new ImageIcon(getClass().getResource("/meat_3.png"));
    			meat = meat_1.getImage();
    			meatShape = meat.getScaledInstance(115, 76, java.awt.Image.SCALE_SMOOTH);
    			meat2 = new ImageIcon(meatShape);
    			i1 = new JButton(meat2);
    			i1.setBounds(463, 430, 115, 76);
    			label.add(i1);
    			i1.setActionCommand("itemM");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			break;
    		case 3:
    			meat_1 = new ImageIcon(getClass().getResource("/meat_4.jpeg"));
    			meat = meat_1.getImage();
    			meatShape = meat.getScaledInstance(220, 45, java.awt.Image.SCALE_SMOOTH);
    			meat2 = new ImageIcon(meatShape);
    			i1 = new JButton(meat2);
    			i1.setBounds(848, 510, 215, 45);
    			label.add(i1);
    			i1.setActionCommand("itemM");
    			i1.addActionListener(new ButtonListener());
    			i1.addActionListener(e -> frame.dispose());
    			break;
    		default:
    			break;
    		}		
    		change = new JButton("Change Aisle");
    		change.setBounds(640, 630, 100, 50);
    		label.add(change);
    		change.setActionCommand("aisleNext");
    		change.addActionListener(new ButtonListener());
    		change.addActionListener(e -> frame.dispose());
    		leave = new JButton("Exit Aisle");
    		leave.setBounds(500, 630, 100, 50);
    		label.add(leave);
    		leave.setActionCommand("aisle0");
    		leave.addActionListener(new ButtonListener());
    		leave.addActionListener(e -> frame.dispose());
    		break;
    	case 5: //AISLE 5
    		frame = new JFrame("Aisle 5? (What is here?)");
    		frame.setSize(1250,750);
    		frame.setLocationRelativeTo(null);
    		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    		// Secret aisle that can only be found by digging through the code
    		// Congratulations on finding it!
    		// SEE AISLE 1 FOR CODE BREAKDOWN (line 315)
    // MenuBar
    		frame.setJMenuBar(menuBar);
    // Background
    		frame.add(label);
    		frame.setVisible(true);
    // Shelved Item spawns
    		ImageIcon gold_1 = new ImageIcon(getClass().getResource("/gold_1.png"));
			Image gold = gold_1.getImage();
			Image goldShape = gold.getScaledInstance(100, 180, java.awt.Image.SCALE_SMOOTH);
			ImageIcon gold2 = new ImageIcon(goldShape);
			i1 = new JButton(gold2);
			i1.setBounds(575, 430, 100, 180);
			label.add(i1);
			i1.setActionCommand("itemG");
			i1.addActionListener(new ButtonListener());
			i1.addActionListener(e -> frame.dispose());
			
    		change = new JButton("Change Aisle");
    		change.setBounds(640, 630, 100, 50);
    		label.add(change);
    		change.setActionCommand("aisleNext");
    		change.addActionListener(new ButtonListener());
    		change.addActionListener(e -> frame.dispose());
    		leave = new JButton("Exit Aisle");
    		leave.setBounds(500, 630, 100, 50);
    		label.add(leave);
    		leave.setActionCommand("aisle0");
    		leave.addActionListener(new ButtonListener());
    		leave.addActionListener(e -> frame.dispose());
    		break;
    	}
    }
// REGISTER AS CUSTOMER    
    public void registerGUI() {
    	JFrame frame = new JFrame("Register");
    	frame.setSize(1000, 750);
    	frame.setLocationRelativeTo(null);
    	frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	// creates the register checkout window
    // Menu Bar
    	menuBar = new JMenuBar();
    	help = new JMenu("Help");
        loc = new JMenuItem("Current Location");
        list = new JMenuItem("Print Shopping List");
        String money = String.format("%.2f", playable.getMoney());
        wallet = new JMenuItem("Wallet: $" + money);
        exit = new JMenuItem("Exit");
        help.add(loc);
        help.add(list);
        help.add(wallet);
        help.add(exit);
        loc.addActionListener(new MenuListener());
        list.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        menuBar.add(help);
        frame.setJMenuBar(menuBar);
        JMenu cart = new JMenu("Shopping Cart");
		for (Item i : ((Customer)playable).getShoppingCart()) {
			String price = String.format("%.2f", i.getPrice() * i.getAmount());
			JMenuItem x = new JMenuItem(i.getAmount() + ": " + i.getName() + " : $" + price);
			cart.add(x);
		}
		menuBar.add(cart);
		// creates the menu bar for the window
    // Background
    	ImageIcon background = new ImageIcon(getClass().getResource("/register_1.png"));
    	Image img = background.getImage();
    	Image imgscaled = img.getScaledInstance(1500, 750, java.awt.Image.SCALE_SMOOTH);
    	ImageIcon pic = new ImageIcon(imgscaled);
    	JLabel label = new JLabel(pic);
    	frame.add(label);
    // Return Cart
    	JButton rtn = new JButton("Return Order");
    	rtn.setBounds(200, 550, 100, 50);
    	label.add(rtn);
    	rtn.setActionCommand("return");
    	rtn.addActionListener(new ButtonListener());
    	rtn.addActionListener(e -> frame.dispose());
    	// return order will clear the players shopping cart and return to idle state/screen
    // Buy Item Button
    	JButton buy = new JButton("Buy Cart");
    	buy.setBounds(650, 350, 100, 50);
    	label.add(buy);
    	buy.setActionCommand("buyI");
    	buy.addActionListener(new ButtonListener());
    	buy.addActionListener(e -> frame.dispose());
    	frame.setVisible(true);
    	// buy cart will purchase the players shopping cart
    }
    public void endGUI() {
    	JFrame frame = new JFrame("Game Over");
    	frame.setSize(500,500);
    	frame.setLocationRelativeTo(null);
    	frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	// GAME OVER screen if you lose (didnt complete shopping List)
    // Menu Bar
    	menuBar = new JMenuBar();
    	help = new JMenu("Help");
        list = new JMenuItem("Print Shopping List");
        exit = new JMenuItem("Exit");
        String money = String.format("%.2f", playable.getMoney());
        wallet = new JMenuItem("Wallet: $" + money);
        help.add(list);
        help.add(wallet);
        help.add(exit);
        list.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        menuBar.add(help);
        frame.setJMenuBar(menuBar);
    // Background
        ImageIcon background = new ImageIcon(getClass().getResource("/game_over.jpeg"));
    	Image img = background.getImage();
    	Image imgscaled = img.getScaledInstance(500, 500, java.awt.Image.SCALE_SMOOTH);
    	ImageIcon pic = new ImageIcon(imgscaled);
    	JLabel label = new JLabel(pic);
    	frame.add(label);
    // Exit Button
    	JButton end = new JButton("Exit");
    	end.setBounds(250,350,100,50);
    	label.add(end);
    	end.setActionCommand("exit");
    	end.addActionListener(new ButtonListener());
    	end.addActionListener(e -> frame.dispose());
    	frame.setVisible(true);
    }
    public void winGUI() {
    	JFrame frame = new JFrame("You Win");
    	frame.setSize(500,500);
    	frame.setLocationRelativeTo(null);
    	frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	// YOU WIN screen for completing your shopping List
    // Menu Bar
    	menuBar = new JMenuBar();
    	help = new JMenu("Help");
        list = new JMenuItem("Print Shopping List");
        exit = new JMenuItem("Exit");
        String money = String.format("%.2f", playable.getMoney());
        wallet = new JMenuItem("Wallet: $" + money);
        help.add(list);
        help.add(wallet);
        help.add(exit);
        list.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        menuBar.add(help);
        frame.setJMenuBar(menuBar);
    // Background
        ImageIcon background = new ImageIcon(getClass().getResource("/you_win.jpeg"));
    	Image img = background.getImage();
    	Image imgscaled = img.getScaledInstance(500, 500, java.awt.Image.SCALE_SMOOTH);
    	ImageIcon pic = new ImageIcon(imgscaled);
    	JLabel label = new JLabel(pic);
    	frame.add(label);
    // Exit Button
    	JButton end = new JButton("Exit");
    	end.setBounds(350,375,100,50);
    	label.add(end);
    	end.setActionCommand("exit");
    	end.addActionListener(new ButtonListener());
    	end.addActionListener(e -> frame.dispose());
    	frame.setVisible(true);
    }
// JMENUBAR DECLARATIONS    
    public void baseGUI() {
        menuBar = new JMenuBar();
        // initializes the menu bar
        window = new JMenu("Window");
        exit = new JMenuItem("Exit");
        // creates the menu title and drop down item
        window.add(exit);
        exit.addActionListener(new MenuListener());
        // adds function to the item if clicked
        menuBar.add(window);
        // adds the item to the bar
        setJMenuBar(menuBar);
        // adds the bar to the frame
    }
    
    public void secretGUI() {
    	JFrame frame = new JFrame("You Win (Secret Ending)");
    	frame.setSize(500,500);
    	frame.setLocationRelativeTo(null);
    	frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    	// YOU WIN screen for secret ending (what could cause this ending?)
    // Menu Bar
    	menuBar = new JMenuBar();
    	help = new JMenu("Help");
        exit = new JMenuItem("Exit");
        String money = String.format("%.2f", playable.getMoney());
        help.add(exit);
        exit.addActionListener(new MenuListener());
        menuBar.add(help);
        frame.setJMenuBar(menuBar);
    // Background
        ImageIcon background = new ImageIcon(getClass().getResource("/you_win_secret.jpeg"));
    	Image img = background.getImage();
    	Image imgscaled = img.getScaledInstance(500, 500, java.awt.Image.SCALE_SMOOTH);
    	ImageIcon pic = new ImageIcon(imgscaled);
    	JLabel label = new JLabel(pic);
    	frame.add(label);
    // Exit Button
    	JButton end = new JButton("Exit");
    	end.setBounds(350,375,100,50);
    	label.add(end);
    	end.setActionCommand("exit");
    	end.addActionListener(new ButtonListener());
    	end.addActionListener(e -> frame.dispose());
    	frame.setVisible(true);
    }
// JMENUITEM FUNCTIONS
    private class MenuListener implements ActionListener{
    	// This method allows menu items to have function and call an action when clicked
        public void actionPerformed(ActionEvent e) {
        	JMenuItem source = (JMenuItem) (e.getSource());
        	if (source.equals(exit)) {
        		System.exit(0);
        		// exit will terminate the program
        	} else
        	if (source.equals(loc)) {
        		handleLocation();
        		// loc will display to the player where they are
        	} else 
        	if (source.equals(list)) {
        		printList();
        		// list will print the players shopping list in a separate window
        	}
        	else if (source.equals(printCompany)) {
        		printCompany();
        		// displays the company
        	}
        	else if (source.equals(workerPay)) {
        		
        	}
        	else if (source.equals(employeeListCompany)) {
        		printEmployee();
        		// displays the company's employee list
        	}
        }
    }
// BUTTON FUNCTIONS    
    private class ButtonListener implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
    		// Allows buttons to have function and execute/call methods
    		if (e.getActionCommand().equals("customer")) {
    			playable = fry.getCustomersInBuilding().get(0);
    			// sets the player as the first customer in the building (see driver for details)
    			customerGUI();
    			// builds the Customer's first GUI
    		} 
			if (e.getActionCommand().equals("company")) {
				playable_2 = fry.getCompany();
				// sets the player as the company managing the fry's
				companyGUI();
				// builds the company's GUI
			}
			if (e.getActionCommand().equals("hire")) {
				companyHire();
				// hires an employee
			}
			if (e.getActionCommand().equals("buy_wholesale")) {
				companyBuy();
				// buys wholesale for the company stock
			}
            else if (e.getActionCommand().equals("enter")) {
    			playable.setLocation(1);
    			// sets the customer player's location as "inside the fry's"
    			buildingGUI();
    			// builds the idle screen GUI
    		}
            else if (e.getActionCommand().equals("check_out")) {
            	checkOutGUI();
            	// builds the worker checkout screen
            }
            else if (e.getActionCommand().equals(("worker_enter"))) {
            	playable.setLocation(3);
            	// sets the worker player's location as "at the register"
            	workerInFrysGUI();
            	// builds the worker at register screen
            }
            else if (e.getActionCommand().equals("register")) {
            	playable.setLocation(3);
            	// sets the customer player's location as "at the register"
            	registerGUI();
            	// builds the customer's register GUI
            }
            else if (e.getActionCommand().equals("wholesaler")) {
                playable_2 = fry.getWholesaler();
                // sets the player as a wholesaler
				wholesalerGUI();
				// builds the wholesaler GUI
            }
            else if (e.getActionCommand().equals("worker")) {
            	playable = fry.getWorkersInBuilding().get(0);
            	workerGUI();
            } 
            else if (e.getActionCommand().equals("aisle1")) {
            	playable.setLocation(2);
            	((Customer) playable).setAisle(1);
            	aisleGUI();
            }
            else if (e.getActionCommand().equals("aisle0")) {
            	playable.setLocation(1);
            	((Customer) playable).setAisle(0);
            	buildingGUI();
            }
            else if (e.getActionCommand().equals("drive")) {
            	driveToFrys();
            }
            else if (e.getActionCommand().equals("sell")) {
            	sellWholesaler();
            }
            else if (e.getActionCommand().equals("itemV")) {
            	for (Item i : fry.companies.get(0).getStock()) {
            		if (i.getName() == "vegetable") {
            			((Customer)playable).addItem(((Customer)playable).getAisle(), i, 1);
            			// if the item is in stock at the company, the item is added to the customer's shopping cart
            			break;
            		}
            	}
            	aisleGUI();
            }
            else if (e.getActionCommand().equals("itemB")) {
            	for (Item i : fry.companies.get(0).getStock()) {
            		if (i.getName() == "bread") {
            			((Customer)playable).addItem(((Customer)playable).getAisle(), i, 1);
            			break;
            		}
            	}
            	aisleGUI();
            }
            else if (e.getActionCommand().equals("itemM")) {
            	for (Item i : fry.companies.get(0).getStock()) {
            		if (i.getName() == "meat") {
            			((Customer)playable).addItem(((Customer)playable).getAisle(), i, 1);
            			break;
            		}
            	}
            	aisleGUI();
             }
            else if (e.getActionCommand().equals("itemG")) {
            	for (Item i : fry.companies.get(0).getStock()) {
            		if (i.getName() == "Golden HotDog") {
            			((Customer)playable).addItem(((Customer)playable).getAisle(), i, 1);
            			break;
            		}
            	}
            	buildingGUI();
            }
            else if (e.getActionCommand().equals("buyI")) {
            	boolean done = false;
            	boolean gh = false;
            	double total = 0;
            	for (Item i : ((Customer)playable).shoppingList) {
            		for (Item j : ((Customer)playable).shoppingCart) {
            			if (j.getName().equals(i.getName())) {
            				if (j.getAmount() == i.getAmount()) {
            					done = true;
            				} else {
            					done = false;
            				}
            				// checks if the players shopping cart matches their shopping list
            			}
            			if (j.getName().equals("Golden HotDog")) {
            				gh = true;
            			}
            			// checks if the player has the golden hotdog in their cart
            		}
            	}
            	for (Item x : ((Customer)playable).shoppingCart) {
            		total = total + (x.getAmount() * x.getPrice());
            	}
            	
            	((Customer)playable).purchaseItems(fry);
            	// purchases the items throught the system
            	String money = String.format("%.2f", playable.getMoney());
            	JOptionPane.showMessageDialog(null, "Remaining Money: $" + money, "Transaction Complete", JOptionPane.PLAIN_MESSAGE);
            	// displays remaining money after transaction (if you drop below $0.00, you cannot purchase items
            	if (gh == true && ((Customer)playable).money > total) {
            		secretGUI();
            		// if the golden hotdog is present in the cart, secret ending(?)
            	} else {
            		if (done == true) {
            			winGUI();
            			// if (the cart items matched the shopping list) { you win! }
            		} else {
            			endGUI();
            			// else { you lose }
            		}
            	}
            }
            else if (e.getActionCommand().equals("return")) {
            	if (((Customer)playable).shoppingCart.size() > 0) {
            		((Customer)playable).shoppingCart = new ArrayList<Item>();
            	}
            	buildingGUI();
            	// builds the return order button (see line 760)
            }
            else if (e.getActionCommand().equals("aisleNext")) {
            	JTextField num = new JTextField();
            	Object [] input = {"Aisle Number (1-4):", num}; // only aisles 1-4 will be explained (aisle 5 is hidden)
            	int option = JOptionPane.showConfirmDialog(null, input, "Change Aisle", JOptionPane.OK_CANCEL_OPTION);
            	// creates a pop-up that prompts an integer input to change aisles
            	if (option == JOptionPane.OK_OPTION && num.getText().length() > 0) {
            		if (Integer.parseInt(num.getText()) <= 5 && Integer.parseInt(num.getText()) > 0) {
            			
                    	((Customer) playable).setAisle(Integer.parseInt(num.getText()));
            		} else {
                		JOptionPane.showMessageDialog(null, "Aisle " + Integer.parseInt(num.getText()) + " does not exist.", "Error", JOptionPane.PLAIN_MESSAGE);
                	}
            		// if the aisle doesn't exist, the aisle won't change, else it will change to the inputted aisle number
            	} 
            	aisleGUI();
            	// builds the aisle GUI (in accordance to the aisle number)
            }
            else if (e.getActionCommand().equals("fire")) {
            	JOptionPane.showMessageDialog(null, "Building is on Fire, Leave", "FIRE!", JOptionPane.PLAIN_MESSAGE);
            	System.exit(0);
            	// building is on fire, you cannot enter
            }
            else if (e.getActionCommand().equals("exit")) {
            	System.exit(0);
            	// exits the building and the game
            }
    	}
    }
// DISPLAY LOCATION    
    private void handleLocation() {
    	switch(playable.getLocation()) {
    	// displays the current location of the player (0, 1, 2, 3 corresponds to a location)
    		case 0:
    			JOptionPane.showMessageDialog(null, "Location is outside the Fry's", "Current Location", JOptionPane.PLAIN_MESSAGE);
    			break;
    		case 1:
    			JOptionPane.showMessageDialog(null, "Location is inside the Fry's", "Current Location", JOptionPane.PLAIN_MESSAGE);
    			break;
    		case 2:
    			JOptionPane.showMessageDialog(null, "Location is inside aisle " + ((Customer) playable).getAisle(), "Current Location", JOptionPane.PLAIN_MESSAGE);
    			break;
    		case 3:
    			JOptionPane.showMessageDialog(null, "Location is at the register", "Current Location", JOptionPane.PLAIN_MESSAGE);
    			break;
    	}		
    }
// PRINT ITEM LIST    
    private void printList() {
    	// prints the players shopping list in a separate window
    	JFrame list = new JFrame("Shopping List");
    	list.setSize(300,600);
    	ByteArrayOutputStream boat = new ByteArrayOutputStream();
		PrintStream stream = new PrintStream(boat);
		PrintStream old = System.out;
		System.setOut(stream);
		playable.PrintList(((Customer)playable).shoppingList);
		System.out.flush();
		System.setOut(old);
		JTextArea textArea = new JTextArea(boat.toString());  
		textArea.setWrapStyleWord(true); 
		list.add(textArea);
    	list.setVisible(true);
    }

    public void wholesalerGUI() {
        JFrame frame = new JFrame("Wholesaler");
        frame.setSize(1250,750);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
    // Menu Bar
    	menuBar = new JMenuBar();
    	actions = new JMenu("Actions");
      //  drive = new JMenuItem("Drive to Fry's");
      //  sell = new JMenuItem("Sell Wholesale");
        exit = new JMenuItem("Exit");
      //  actions.add(drive);
      //  actions.add(sell);
        actions.add(exit);
       // drive.addActionListener(new MenuListener());
       // sell.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        menuBar.add(actions);
        frame.setJMenuBar(menuBar);
    // Background
        ImageIcon background = new ImageIcon(getClass().getResource("/wholesaler_warehouse.jpg"));
        Image background2 = background.getImage();
        Image scaled = background2.getScaledInstance(1250, 750, java.awt.Image.SCALE_SMOOTH);
        ImageIcon back = new ImageIcon(scaled);
        JLabel label = new JLabel(back);
    	frame.add(label);
    	
    // buttons
    	JButton drive = new JButton("Drive to Fry's");
        drive.setBounds(560, 495, 200, 50);
        label.add(drive);
        drive.setActionCommand("drive");
        drive.addActionListener(new ButtonListener());
        drive.addActionListener(e -> frame.dispose());
    // Build GUI
        frame.setVisible(true);

    }
    
    public void driveToFrys() {
    	JFrame frame = new JFrame("Wholesaler");
        frame.setSize(1250,750);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
    // Menu Bar
    	menuBar = new JMenuBar();
    	actions = new JMenu("Actions");
      //  drive = new JMenuItem("Drive to Fry's");
      //  sell = new JMenuItem("Sell Wholesale");
        exit = new JMenuItem("Exit");
      //  actions.add(drive);
      //  actions.add(sell);
        actions.add(exit);
       // drive.addActionListener(new MenuListener());
       // sell.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        menuBar.add(actions);
        frame.setJMenuBar(menuBar);
    // Background
        ImageIcon background = new ImageIcon(getClass().getResource("/selling_wholesale.jpg"));
        Image background2 = background.getImage();
        Image scaled = background2.getScaledInstance(1250, 750, java.awt.Image.SCALE_SMOOTH);
        ImageIcon back = new ImageIcon(scaled);
        JLabel label = new JLabel(back);
    	frame.add(label);
    	
    // buttons
    	JButton drive = new JButton("Sell Wholesale");
        drive.setBounds(560, 495, 200, 50);
        label.add(drive);
        drive.setActionCommand("sell");
        drive.addActionListener(new ButtonListener());
        drive.addActionListener(e -> frame.dispose());
    // Build GUI
        frame.setVisible(true);

    }
    
    public void sellWholesaler() {
    	
    	JFrame frame = new JFrame("Wholesaler");
        frame.setSize(1250,750);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    // Menu Bar
    	menuBar = new JMenuBar();
    	actions = new JMenu("Actions");
        exit = new JMenuItem("Exit");
        actions.add(exit);
        exit.addActionListener(new MenuListener());
        menuBar.add(actions);
        frame.setJMenuBar(menuBar);
    // Background
        ImageIcon background = new ImageIcon(getClass().getResource("/selling_wholesale.jpg"));
        Image background2 = background.getImage();
        Image scaled = background2.getScaledInstance(1250, 750, java.awt.Image.SCALE_SMOOTH);
        ImageIcon back = new ImageIcon(scaled);
        JLabel label = new JLabel(back);
    	frame.add(label);

    	String success = "";
    	double oldMoney = playable_2.getMoney();
    	success = ((Wholesaler) playable_2).sellWholesale();
    		if (success == "empty") {
    			JOptionPane.showMessageDialog(null, playable_2.getName() + " does not have any stock to sell - Press 'OK' to exit", "Wholesale Message", JOptionPane.PLAIN_MESSAGE);
    			System.exit(0);
    		}
    	double gain = playable_2.getMoney() - oldMoney;
    		JOptionPane.showMessageDialog(null, playable_2.getName() + " has made " + gain + " dollars - Press 'OK' to exit", "Wholesale Message", JOptionPane.PLAIN_MESSAGE);
    			System.exit(0);
    	
    }
    
	public void companyGUI() {
		JFrame frame = new JFrame("Company");
        frame.setSize(1250,750);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
    // Menu Bar
    	menuBar = new JMenuBar();
    	actions = new JMenu("Actions");
    	printCompany = new JMenuItem("Print Company Stock");
    	employeeListCompany = new JMenuItem("Print Employee List");
    	actions.add(printCompany);
    	actions.add(employeeListCompany);
        exit = new JMenuItem("Exit");
        actions.add(exit);
        printCompany.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        employeeListCompany.addActionListener(new MenuListener());
        menuBar.add(actions);
        frame.setJMenuBar(menuBar);
    // Background
        ImageIcon background = new ImageIcon(getClass().getResource("/company_main.jpg"));
        Image background2 = background.getImage();
        Image scaled = background2.getScaledInstance(1250, 750, java.awt.Image.SCALE_SMOOTH);
        ImageIcon back = new ImageIcon(scaled);
        JLabel label = new JLabel(back);
    	frame.add(label);
    	
    // buttons
    	JButton hire = new JButton("Hire Employee");
        hire.setBounds(650, 495, 200, 50);
        label.add(hire);
        hire.setActionCommand("hire");
        hire.addActionListener(new ButtonListener());
        hire.addActionListener(e -> frame.dispose());

		JButton buy = new JButton("Buy Wholesale");
        buy.setBounds(450, 495, 200, 50);
        label.add(buy);
        buy.setActionCommand("buy_wholesale");
        buy.addActionListener(new ButtonListener());
        buy.addActionListener(e -> frame.dispose());
    // Build GUI
        frame.setVisible(true);
	}
    
	public void companyHire() {
		JTextField name = new JTextField();
            Object [] input = {"Enter the Employee you want to hire:", name};
            int option = JOptionPane.showConfirmDialog(null, input, "Hire Employee", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION && name.getText().length() > 0) {
				for (Person p : Person.persons) {
					if (p.getName().contains(name.getText())) {
						if (!((Company) playable_2).getEmployeeList().contains(p)) {
							((Company) playable_2).hireEmployee(p);
							((Worker) p).hiredBy((Company) playable_2);
							JOptionPane.showMessageDialog(null, "" + name.getText() + " has been hired to work at Fry's", "Hire Successful", JOptionPane.PLAIN_MESSAGE);
							companyGUI();
							return;
						}
						else {
							JOptionPane.showMessageDialog(null, "" + name.getText() + " is already working for the company", "Hire Failed", JOptionPane.PLAIN_MESSAGE);
							companyGUI();
							return;
						}
					}
				}
            } 
			JOptionPane.showMessageDialog(null, "Please enter a valid name of an applicant", "Hire Failed", JOptionPane.PLAIN_MESSAGE);
			companyGUI();
			return;
	}

	public void companyBuy() {
		if (Wholesaler.wholesalerList.isEmpty()) {
			JOptionPane.showMessageDialog(null, "There is no available wholesalers", "Purchase Failed", JOptionPane.PLAIN_MESSAGE);
			companyGUI();
			return;
		}
		else {
			double oldMoney = playable_2.getMoney();
			boolean exists = false;
			Wholesaler theWholesaler = null;
			JTextField name = new JTextField();
            Object [] input = {"Enter the Wholesaler to Purchase from:", name};
            int option = JOptionPane.showConfirmDialog(null, input, "Purchase Wholesale", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION && name.getText().length() > 0) {
            	for (Wholesaler w : Wholesaler.wholesalerList) {
            		if (w.getName().contains(name.getText())) {
            			exists = true;
            			theWholesaler = w;
            		}
            	}
            	if (exists == true) {
            		((Company) playable_2).purchaseWholesale(theWholesaler);
            	}
            	else {
        			JOptionPane.showMessageDialog(null, "Please enter a valid Wholesaler", "Purchase Failed", JOptionPane.PLAIN_MESSAGE);
        			companyGUI();
        			return;
            	}
            }
			double spent = oldMoney - playable_2.getMoney();
			if (spent < 0.00000001) {
				JOptionPane.showMessageDialog(null, "" + theWholesaler.getName() + " does not have any items to sell, try again later", "Purchase Failed", JOptionPane.PLAIN_MESSAGE);
				companyGUI();
				return;
			}
			JOptionPane.showMessageDialog(null, "You have purchased wholesale from " + theWholesaler.getName() + " and have spent " + spent + " dollars", "Purchase Success", JOptionPane.PLAIN_MESSAGE);
			companyGUI();
			return;
		}
	}
	
    private void printCompany() {
    	JFrame list = new JFrame("Company Stock");
    	list.setSize(350,600);
    	ByteArrayOutputStream boat = new ByteArrayOutputStream();
		PrintStream stream = new PrintStream(boat);
		PrintStream old = System.out;
		System.setOut(stream);
		playable_2.printStock();
		System.out.flush();
		System.setOut(old);
		JTextArea textArea = new JTextArea(boat.toString());  
		textArea.setWrapStyleWord(true); 
		list.add(textArea);
    	list.setVisible(true);
    }
    
    private void workerGUI() {
    	JFrame frame = new JFrame("Company");
        frame.setSize(1250,750);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
    // Menu Bar
    	menuBar = new JMenuBar();
    	actions = new JMenu("Help");
    	workerPay = new JMenuItem("Pay Rate: " + ((Worker) playable).getSalary());
    	actions.add(workerPay);
        exit = new JMenuItem("Exit");
        actions.add(exit);
        workerPay.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        menuBar.add(actions);
        frame.setJMenuBar(menuBar);
    // Background
        ImageIcon background = new ImageIcon(getClass().getResource("/Fry.jpeg"));
        Image background2 = background.getImage();
        Image scaled = background2.getScaledInstance(1250, 750, java.awt.Image.SCALE_SMOOTH);
        ImageIcon back = new ImageIcon(scaled);
        JLabel label = new JLabel(back);
    	frame.add(label);
    	
    // buttons
    	JButton enter = new JButton("Enter Fry's");
    	enter.setBounds(560, 495, 100, 50);
        label.add(enter);
        enter.setActionCommand("worker_enter");
        enter.addActionListener(new ButtonListener());
        enter.addActionListener(e -> frame.dispose());

    // Build GUI
        frame.setVisible(true);
    }
    
    private void workerInFrysGUI() {
    	JFrame frame = new JFrame("Register");
    	frame.setSize(1000, 750);
    	frame.setLocationRelativeTo(null);
    	frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    // Menu Bar
    	menuBar = new JMenuBar();
    	help = new JMenu("Help");
        loc = new JMenuItem("Current Location");
//        list = new JMenuItem("Print Shopping List");
        String money = String.format("%.2f", ((Worker)playable).getSalary());
        wallet = new JMenuItem("Salary: $" + money);
        exit = new JMenuItem("Exit");
        help.add(loc);
//        help.add(list);
        help.add(wallet);
        help.add(exit);
        loc.addActionListener(new MenuListener());
//        list.addActionListener(new MenuListener());
        exit.addActionListener(new MenuListener());
        menuBar.add(help);
        frame.setJMenuBar(menuBar);
//        JMenu cart = new JMenu("Shopping Cart");
    // Background
    	ImageIcon background = new ImageIcon(getClass().getResource("/register_with_man.png"));
    	Image img = background.getImage();
    	Image imgscaled = img.getScaledInstance(1500, 750, java.awt.Image.SCALE_SMOOTH);
    	ImageIcon pic = new ImageIcon(imgscaled);
    	JLabel label = new JLabel(pic);
    	frame.add(label);
    // Buy Item Button
    	if (fry.customerInBuilding.size() == checkedOut.size()) {
        	JButton out = new JButton("There are no more customers to check out");
        	out.setBounds(650, 350, 300, 50);
//        	frame.remove(label);
        	ImageIcon background2 = new ImageIcon(getClass().getResource("/register_1.png"));
        	Image img2 = background2.getImage();
        	Image imgscaled2 = img2.getScaledInstance(1500, 750, java.awt.Image.SCALE_SMOOTH);
        	ImageIcon pic2 = new ImageIcon(imgscaled2);
        	JLabel label2 = new JLabel(pic2);
        	label2.add(out);
        	frame.add(label2);
//        	out.setActionCommand("check_out");
//        	out.addActionListener(new ButtonListener());
//        	out.addActionListener(e -> frame.dispose());
        	frame.setVisible(true);
        	return;
    	}
    	checkOutCustomer = fry.getCustomer();
    	while (true) {
    		if (checkedOut.contains(checkOutCustomer)) {
    			checkOutCustomer = fry.getCustomer();
    			if (!checkedOut.contains(checkOutCustomer)) {
    				break;
    			}
    		}
    		else {;
    			break;
    		}
    	}
    	JButton out = new JButton("Check Out Customer " + checkOutCustomer.getName());
    	out.setBounds(650, 350, 250, 50);
    	label.add(out);
    	out.setActionCommand("check_out");
    	out.addActionListener(new ButtonListener());
    	out.addActionListener(e -> frame.dispose());
    	frame.setVisible(true);
    }
    
    private void checkOutGUI() {
    	JOptionPane.showMessageDialog(null, "Checking out " + checkOutCustomer.getName(), "Check Out", JOptionPane.PLAIN_MESSAGE);
    	checkOutCustomer.setListAsCart();
    	if (checkOutCustomer.getShoppingCart().isEmpty()) {
    		JOptionPane.showMessageDialog(null, "" + checkOutCustomer.getName() + " has already been checked out", "Check Out", JOptionPane.PLAIN_MESSAGE);
    		workerInFrysGUI();
    		return;
    	}
    	((Worker) playable).purchaseItems(checkOutCustomer);
    	checkedOut.add(checkOutCustomer);
    	workerInFrysGUI();
    	return;
    }
    
    private void printEmployee() {
    	JFrame list = new JFrame("Employee List");
    	list.setSize(350,600);
    	ByteArrayOutputStream boat = new ByteArrayOutputStream();
		PrintStream stream = new PrintStream(boat);
		PrintStream old = System.out;
		System.setOut(stream);
		((Company)playable_2).printEmployee();
		System.out.flush();
		System.setOut(old);
		JTextArea textArea = new JTextArea(boat.toString());  
		textArea.setWrapStyleWord(true); 
		list.add(textArea);
    	list.setVisible(true);
    }
    
}
