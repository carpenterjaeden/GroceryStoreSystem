package ProjectSoftware.pkg;

import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;

public class GUI_Driver {
	public static void main(String args[]) {
		
	Frys_Food_and_Drug fry = new Frys_Food_and_Drug();
	Company company = new Company();
	Wholesaler ws = new Wholesaler();
	Wholesaler ws2 = new Wholesaler();
	System_Store sys = new System_Store(company);

	Random rand = new Random();
	int upper = 50;
	int rand_int = rand.nextInt(upper);
	
	fry.setOnFire(false);
	if (rand_int == 49 || rand_int == 0) {
		fry.setOnFire(true);
	}
	
	Customer c1 = new Customer();
	Customer c2 = new Customer();
	Customer c3 = new Customer();
	Worker w1 = new Worker();
	Worker w2 = new Worker();
	Person p1 = new Worker();
	Person p2 = new Worker();
	
	Item vegetable = new Item("vegetable", 2.12, 2, true);
	Item bread = new Item("bread", 7.5, 2, true);
    Item meat = new Item("meat", 4.25, 1, true);
    Item golden_hotdog = new Item("Golden HotDog", 99.99, 1, true);
    Item ketchup = new Item("Ketchup", 5.5, 3, true);
    Item pasta = new Item("Pasta", 3.5, 4, true);
	
	
	Item listVegetable = vegetable;
    Item listBread = bread;
    Item listMeat = meat;
    
    Item stockBread = new Item("bread", 7.5, 100, true);
    Item stockVegetable = new Item("vegetable", 2.12, 300, true);
    Item stockMeat = new Item("meat", 4.25, 200, true);
    Item stockGold = golden_hotdog;
    
    Item stockTomato = new Item("tomato", 0.83, 500, true);
    Item stockKetchup = new Item("ketchup", 4.15, 10, true);
    Item stockSauce = new Item("pasta sauce", 3.15, 230, true);
    
// People who can be hired by the company
    p1.setName("Carl");
    p2.setName("Johnny");
    
// Wholesaler: Attributes
    ws.setName("Bob");
    ws.setMoney(10000.0);
    ws.addStock(stockTomato);
    ws.addStock(stockKetchup);
    ws.addStock(stockSauce);
    fry.addWholesaler(ws);
    ws2.setName("Jim");
    ws2.setMoney(10000.0);
    ws2.addStock(stockBread);
    ws2.addStock(stockMeat);
    fry.addWholesaler(ws2);

// Company: Attributes
    company.setName("Fry's Food and Drug");
    company.setMoney(50000000.0);
    company.addStock(stockBread);
    company.addStock(stockVegetable);
    company.addStock(stockMeat);
    company.addStock(stockGold);
    fry.addCompany(company);
    
// Customer: Attributes
    ArrayList<Item> list = new ArrayList<Item>();
    ArrayList<Item> list2 = new ArrayList<Item>();
    ArrayList<Item> list3 = new ArrayList<Item>();
    c1.setName("Oscar");
    c2.setName("Jeffrey");
    c3.setName("Bogdan");
    list.add(listVegetable);
    list.add(listMeat);
    list.add(listBread);
    list2.add(pasta);
    list2.add(bread);
    list2.add(ketchup);
    list2.add(listVegetable);
    list3.add(listMeat);
    list3.add(pasta);
    list3.add(ketchup);
    c1.setShoppingList(list);
	c1.setPaymentOption("Cash");
	c1.setMoney(100.0);
    c2.setShoppingList(list2);
	c2.setPaymentOption("Cash");
	c2.setMoney(160.0);
	c3.setShoppingList(list3);
	c3.setPaymentOption("Cash");
	c3.setMoney(1000.0);
    
// Add People to Building
	fry.addPeople(w1);
	fry.addPeople(w2);
	fry.addPeople(c1);
	fry.addPeople(c2);
	fry.addPeople(c3);
	
// Generate GUI
	Frys_GUI store = new Frys_GUI("Fry's", fry);
	}
}