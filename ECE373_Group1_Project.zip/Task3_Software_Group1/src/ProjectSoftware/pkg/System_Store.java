package ProjectSoftware.pkg;
import java.util.ArrayList;

public class System_Store {
	private static Company owner;

	public System_Store(Company o) {
		owner = o;
	}


	public static void makeReturn(Item i1, Customer p1) {
		for (Item j : owner.getStock()) {
			if (j.getName() == i1.getName()) {
				j.setAmount(j.getAmount() + i1.getAmount());
				p1.setMoney(p1.getMoney() + (i1.getAmount() * i1.getPrice()));
				owner.setMoney(owner.getMoney() - (i1.getAmount() * i1.getPrice()));
				return;			// if the company  does  have the item in stock, the item amount is updated
			} 
		}
		owner.stock.add(i1);	// if the company doesnt have the item in stock, the item is added.
		p1.setMoney(p1.getMoney() + (i1.getAmount() * i1.getPrice()));
		owner.setMoney(owner.getMoney() - (i1.getAmount() * i1.getPrice()));
	}

	public static void makePurchase(Item i1, Person p1) {
		for (Item j : owner.getStock()) {
			if (i1.getName() == j.getName()) {
				owner.setMoney(owner.getMoney() + (i1.getAmount() * i1.getPrice()));
				j.setAmount(j.getAmount() - i1.getAmount());
				p1.setMoney(p1.getMoney() - (i1.getAmount() * i1.getPrice()));
			}
		}
	}
}
