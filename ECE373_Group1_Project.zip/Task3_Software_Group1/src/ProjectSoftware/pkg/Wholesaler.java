package ProjectSoftware.pkg;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Wholesaler extends BusinessEntity {
	
	public String sellWholesale() {
		
		if (stock.size() == 0) {
			return "empty";
		}
		
		for (int i = 0; i < this.stock.size(); i++) {
			this.money = this.money + (this.stock.get(i).getPrice()/2 * this.stock.get(i).getAmount());
				for (int j = 0; j < this.stock.size(); j++) {
					if (stock.get(j) == this.stock.get(i)) {
						stock.remove(j);
					}
			}
		}
		return "success";
	}
}
